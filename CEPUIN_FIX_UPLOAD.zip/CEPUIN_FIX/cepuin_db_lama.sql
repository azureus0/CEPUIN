-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Nov 2025 pada 04.07
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cepuin_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `mode` varchar(50) NOT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `image_path` varchar(500) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `reports`
--

INSERT INTO `reports` (`id`, `username`, `subject`, `description`, `mode`, `file_path`, `image_path`, `timestamp`) VALUES
(5, 'Anonymous', 'y', 'gAAAAABpDA9Jtkv7SuRpLdG2JMN5OfpilqnXhW3KYxSaRXK4l8dKKj8-tMHRnBwJoKxWoPK8mOipuyIU8j3jovQQAgs4-_h-7g==', 'biasa', 'uploads\\files\\6f380d85169a4c978be45d239f82da88_UtsKripto.pdf.enc,uploads\\files\\cbf057dd78114df8bdd2b27d984091be_WhatsApp Image 2025-08-24 at 13.00.33.jpeg.enc', NULL, '2025-11-06 03:00:25'),
(6, 'Anonymous', 'ye', 'gAAAAABpDA952Y6zbicDNfwz3HFH86UOttX0xYC_EwytdSuS2hEVvgzXaPCk_6kziSGrAdE0DBFj8Xh3xoI_wze3vYNxPDPQdw==', 'steganografi', NULL, 'uploads\\images\\stego_ea1ce6e2c03b46acb00b855415bfcf1b_WhatsApp Image 2025-08-09 at 17.07.46.jpeg', '2025-11-06 03:01:13'),
(7, 'Anonymous', 'aa', 'gAAAAABpDBCCcyro0SDIAEgRWssa0BE84w4d2CR9PuzBIeMtTW1PEse8J6FjCuqjOFhiAFmAvFUeoEFfb0_tRX9UiP8xiIKlVA==', 'biasa', 'uploads\\files\\317cc6c4cb8f405aba0e8871ab671855_WhatsApp Image 2025-08-18 at 23.15.44.jpeg.enc', NULL, '2025-11-06 03:05:38');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(32) NOT NULL,
  `role` varchar(50) DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `salt`, `role`) VALUES
(1, 'wadaw', 'b343ed47968bdf1233879fc1191a85c5b4a4938f319369c0f9d26e14ebba756d6e90654007e60b30baddcf16f1a6edce110af3636ba4b9eda0b22cf41944c186', 'efefa7aaa73cd30f2d2da3625ff991a5', 'user'),
(2, 'mamamia', '07fb654ab01708942715011ec25b57faffaa73cb80b69d44dcaaa4688990102b4419a9272d89482a2460441aa6ca8cf3310db546c1835acc38de22ec3bc3a93c', 'e37ade444458d1350eaf2f5908bbbc76', 'user'),
(3, 'yedi', '1d5359dbeada304baef89af67d7622ff09705c18aeef05988ff98c95cfdbf97548da9445de2fd4caedf3f5014807fbb57ec6f70829e1bd79e7bb804c140e014d', '86abae23ecfe1462c728945170946bcf', 'user'),
(4, 'y', '54c21e9ea3c9a5ad33f20cfe75861936059cf05bbca20a9aac4241cf8d55ca1397be8a3feb91588fc8841ded067d65d97eb1b67d77d63ec5e42a509a90c11f07', 'c42856de88f3475a1296450306726d53', 'user'),
(5, 'yooo', '4cb65bd33181d254dfc5f8cf4429c64599b5a63815379bb0b21cff7a3de56616f6c32269695705ab06296d5fc868a53ae4689ee8b1aadecd8b76151914ec8b65', 'de1dd53b9196427ef8656dc199316046', 'user'),
(6, 'e', 'c2a8b7b2afb7fc44fafdf442e55c666b77bf06bcad138236eb1bc667af389ee0674f2acbe1629b069a9ef8da0c376304560c8f8af0eaba896a9e7bee5fd57967', '47f328128c06d5695f0b8475ca744690', 'user');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
